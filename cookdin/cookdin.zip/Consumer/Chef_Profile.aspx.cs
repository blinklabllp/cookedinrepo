﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Chef_Profile : System.Web.UI.Page
{
    Myconnection con = new Myconnection();
    SP_MyConnection con1 = new SP_MyConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string Chef_Id = Request.QueryString.Get("Chef_ID");
            //Session["Chef_ID"] = "93";
            //Session["Chef_UserName"] = "ChefX";
            SqlParameter[] p = new SqlParameter[1];
            p[0] = new SqlParameter("@Chef_ID", Chef_Id);

            DataRow dr = con1.SingleRow("SP_PerticularChef_View", p);
            //string fname = dr["Chef_Fname"].ToString();
            //string mname = dr["Chef_Mname"].ToString();
            //string lname = dr["Chef_Lname"].ToString();

            lblUserName.Text = dr["Chef_UserName"].ToString();
            lblDescription.Text = dr["Detail"].ToString();
            lblNoOfDishes.Text = "Numbers Of Dishes";
            lblNoOfReviews.Text = "Noumbers of Reviews";
            ProfilePhoto.ImageUrl = "~/Profile_Photo/" + dr["Photo"].ToString();



           
        }
    }
    //protected void btnEditProfile_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("~/Chef/EditProfile.aspx");
    //}
    //protected void Button1_Click(object sender, EventArgs e)
    //{
    //    Response.Redirect("~/Chef/ListDish.aspx");
    //}
}