﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;

/// <summary>
/// Summary description for commonfunctions
/// </summary>
public class commonfunctions
{
	public commonfunctions()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public XElement GetGeocodingSearchResults(string address)
    {
        // Use the Google Geocoding service to get information about the user-entered address
        // See http://code.google.com/apis/maps/documentation/geocoding/index.html for more info...
        var url = String.Format("http://maps.google.com/maps/api/geocode/xml?address={0}&sensor=false", HttpContext.Current.Server.UrlEncode(address));

        // Load the XML into an XElement object (whee, LINQ to XML!)
        var results = XElement.Load(url);

        // Check the status
        var status = results.Element("status").Value;
        if (status != "OK" && status != "ZERO_RESULTS")
            // Whoops, something else was wrong with the request...
            throw new ApplicationException("There was an error with Google's Geocoding Service: " + status);

        return results;
    }
    public double distance(double lat1, double lon1, double lat2, double lon2, char unit)
    {
        double theta = lon1 - lon2;
        double dist = Math.Sin(deg2rad(lat1)) * Math.Sin(deg2rad(lat2)) + Math.Cos(deg2rad(lat1)) * Math.Cos(deg2rad(lat2)) * Math.Cos(deg2rad(theta));
        dist = Math.Acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;
        if (unit == 'K')
        {
            dist = dist * 1.609344;
        }
        else if (unit == 'N')
        {
            dist = dist * 0.8684;
        }
        return (dist);
    }

    //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    //::  This function converts decimal degrees to radians             :::
    //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    public double deg2rad(double deg)
    {
        return (deg * Math.PI / 180.0);
    }

    //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    //::  This function converts radians to decimal degrees             :::
    //:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
    public double rad2deg(double rad)
    {
        return (rad / Math.PI * 180.0);
    }
}