﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for CheckUserSession
/// </summary>
public class CheckUserSession
{
	public CheckUserSession()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public bool Check_Chef_User(string sessionvalue)
    {

        if (sessionvalue == "")
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}