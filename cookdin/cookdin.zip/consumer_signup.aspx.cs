﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Net;
using System.Security.Cryptography;
using System.IO;
using System.Text;

public partial class consumer_signup : System.Web.UI.Page
{
    SP_MyConnection con1 = new SP_MyConnection();
    Myconnection con = new Myconnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
    }
    protected void btnregister_Click(object sender, EventArgs e)
    {
        //check username
        if (con.check_data("Select * from ConsumerSignUp where Consumer_UserName='"+txtusername.Text+"'"))
        {
            txtemailid.BorderColor = txtpassword.BorderColor;
            txtemailid.BorderStyle = txtpassword.BorderStyle;
            txtusername.BorderColor = System.Drawing.Color.Red;
            txtusername.BorderStyle = BorderStyle.Solid;
            lblerrormessage.Text = "UserName Already In Used";
            lblerrormessage.ForeColor = System.Drawing.Color.Red;
        }
        else
        {
            //check Email
            if (con.check_data("Select * from ConsumerSignUp where Consumer_EmailID='"+txtemailid.Text+"'"))
            {
                txtusername.BorderColor = txtpassword.BorderColor;
                txtusername.BorderStyle = txtpassword.BorderStyle;
                txtemailid.BorderColor = System.Drawing.Color.Red;
                txtemailid.BorderStyle = BorderStyle.Solid;
                lblerrormessage.Text = "EmailId Already In Used";
                lblerrormessage.ForeColor = System.Drawing.Color.Red;
            }
            else
            {

                txtusername.BorderStyle = txtpassword.BorderStyle;
                txtemailid.BorderStyle = txtpassword.BorderStyle;
                txtusername.BorderColor = txtpassword.BorderColor;
                txtemailid.BorderColor = txtpassword.BorderColor;

                lblerrormessage.Text = "";
                lblerrormessage.ForeColor = System.Drawing.Color.Black;

                SqlParameter[] p = new SqlParameter[3];

                p[0] = new SqlParameter("@Email", txtemailid.Text);
                p[1] = new SqlParameter("@User_Name", txtusername.Text);
                p[2] = new SqlParameter("@Password", txtpassword.Text);

                con1.Ins_Upd_Del("SP_ConsumerSignUp_Insert", p);
               
               


                /// Send Email..
        sending_Mail();
                lblerrormessage.Text = "Registration Successfully..";
                lblerrormessage.ForeColor = System.Drawing.Color.Blue;
                Clear_all();

            }
        }
    }
    public void sending_Mail()
    {
        try
        {
            string smtpAddress = "smtp.gmail.com";
            int portNumber = 587;
            bool enableSSL = true;

            string emailFrom = "hiralkanojiya22@gmail.com";
            string password = "Hiral218kanojiya";
            string emailTo = txtemailid.Text;
            string subject = "Confirmation of joining..";
            string body = "Thank You for Joining, Your UserName is :" + txtusername.Text + " and Password is :" + txtpassword.Text + "<br /><a href='http://cookedin.com/Sucess.aspx?userName='" + txtusername.Text + "''><H1><Center>Verify Now</Center></H1></a>";

            using (MailMessage mail = new MailMessage())
            {
                mail.From = new MailAddress(emailFrom);
                mail.To.Add(emailTo);
                mail.Subject = subject;
                mail.Body = body;
                mail.IsBodyHtml = true;
                // Can set to false, if you are sending pure text.

                //mail.Attachments.Add(new Attachment("C:\\SomeFile.txt"));
                //mail.Attachments.Add(new Attachment("C:\\SomeZip.zip"));

                using (SmtpClient smtp = new SmtpClient(smtpAddress, portNumber))
                {
                    smtp.Credentials = new NetworkCredential(emailFrom, password);
                    smtp.EnableSsl = enableSSL;
                    smtp.Send(mail);
                }
            }
        }
        catch (Exception ex)
        {
        }
    }

  
    //Encrypt
    public string EncryptString(string plainText)
    {
       string initVector = "pemgail9uzpgzl88";
    // This constant is used to determine the keysize of the encryption algorithm.
     int keysize = 256;
        string passPhrase = "c00ked!n";
        byte[] initVectorBytes = Encoding.UTF8.GetBytes(initVector);
        byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
        PasswordDeriveBytes password = new PasswordDeriveBytes(passPhrase, null);
        byte[] keyBytes = password.GetBytes(keysize / 8);
        RijndaelManaged symmetricKey = new RijndaelManaged();
        symmetricKey.Mode = CipherMode.CBC;
        ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
        MemoryStream memoryStream = new MemoryStream();
        CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
        cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
        cryptoStream.FlushFinalBlock();
        byte[] cipherTextBytes = memoryStream.ToArray();
        memoryStream.Close();
        cryptoStream.Close();
        return Convert.ToBase64String(cipherTextBytes);
    }



    //public void send_Mail()
    //{
    //    string from = "hiralkanojiya22@gmail.com";
    //    //string to = txtemailid.Text;
    //    string to = "hiralkanojiya88@gmail.com";
    //    MailMessage mail = new MailMessage();
    //   // mail.To.Add(to);
    //    mail.To.Add(new MailAddress(to));
    //    mail.From = new MailAddress(from, "Cookd'n");
    //    mail.Subject = "Confirmation of joining..";
    //    mail.SubjectEncoding = System.Text.Encoding.UTF8;
    //    mail.Body = "Thank You for Joining, Your UserName is :" + txtusername.Text + " and Password is :" + txtpassword.Text;
    //    mail.BodyEncoding = System.Text.Encoding.UTF8;
    //    mail.IsBodyHtml = true;
    //    SmtpClient client = new SmtpClient();

    //    client.Credentials = new System.Net.NetworkCredential(from, "Hiral218kanojiya");
    //    client.Port = 587;
    //    //client.Port = 25;
    //    client.DeliveryMethod = SmtpDeliveryMethod.Network;
    //    client.UseDefaultCredentials = false;
    //   client.Host = "smtp.gmail.com";
    //   // client.Host = "smtp.google.com";
    //    client.EnableSsl = true;


    //    //MailMessage mail = new MailMessage("you@yourcompany.com", "user@hotmail.com");
    //    //SmtpClient client = new SmtpClient();


    //    //mail.Subject = "this is a test email.";
    //    //mail.Body = "this is my test email body";
    //    //client.Send(mail);



    //    try
    //    {
    //        client.Send(mail);

    //        // Label1.Text = "Sent";
    //    }
    //    catch (Exception ex)
    //    {
    //        string errormessage = string.Empty;
    //        while (ex != null)
    //        {
    //            //errormessage = ex.ToString();
    //            //ex = ex.InnerException;
    //            //HttpContext.Current.Response.Write(errormessage);
    //        }
    //    }
    //}
    private void Clear_all()
    {
        txtusername.BorderStyle = txtpassword.BorderStyle;
        txtemailid.BorderStyle = txtpassword.BorderStyle;
        txtusername.BorderColor = txtpassword.BorderColor;
        txtemailid.BorderColor = txtpassword.BorderColor;
        txtconfirmpassword.Text = "";
        txtemailid.Text = "";
        txtpassword.Text = "";
        txtusername.Text = "";
    }
}