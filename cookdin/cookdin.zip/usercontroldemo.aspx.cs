﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class usercontroldemo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       // SqlParameter[] p = new SqlParameter[1];
        //p[0] = new SqlParameter("@Mode", 1);
       // dishlist.passparameter = p;
    }
}